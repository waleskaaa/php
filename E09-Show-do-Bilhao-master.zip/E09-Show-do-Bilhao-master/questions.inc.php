<?php 

    $lastIndex = 5;
    $questions = [
        1 => "Qual filme Barbie uma garota órfã é sorteada para estudar em uma escola especial?",
        2 => "Qual filme Barbie a pequena princesa Rosella cresce numa ilha deserta?",
        3 => "Qual o nome da irmã mais nova da Barbie?",
        4 => "Qual o nome da série da Barbie?",
    ];

    $alternatives = [
        1 => ["Barbie e o segredo das fadas", "Barbie a princesa e a popstar", "Barbie escola de princesas", "Barbie e o castelo de diamante"],
        2 => ["Barbie moda e magia", "Barbie em a princesa da ilha", "Barbie e o castelo de diamantes", "Barbie em a princesa e a plebeia"],
        3 => ["Skipper", "Stacie", "Chelsea", "Raquelle"],
        4 => ["Pinkhouse", "Dreamhouse", "Barbie e o castelo de diamantes", "Barbie"]
    ];

    $answers = [
        1 => "Barbie escola de princesas",
        2 => "Barbie em a princesa da ilha",
        3 => "Chelsea",
        4 => "Dreamhouse"
    ];
?> 