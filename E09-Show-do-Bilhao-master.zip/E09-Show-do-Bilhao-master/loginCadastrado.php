<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<div class="content">
    <main>
        <h2>Este login já existe</h2>
        <br>
    </main>
<a href="index.php"><button>Fazer login</button></a>
</div>
</div>
</body>
</html>